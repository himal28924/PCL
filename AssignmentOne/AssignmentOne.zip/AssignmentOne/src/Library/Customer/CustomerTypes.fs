﻿module Library.Customer.CustomerTypes

open System

type CustomerType = 
    | VIACustomer
    | SOSUCustomer
    
