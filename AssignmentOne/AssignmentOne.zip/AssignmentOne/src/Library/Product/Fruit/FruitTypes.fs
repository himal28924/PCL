﻿namespace Library.Product.Fruit.FruitType

type FruitTypes =
    | Apple
    | Banana
    | Orange

type Fruit = {
    FruitType : FruitTypes
}
   
    
    