﻿module Library.Payment.PaymentTypes

type PaymentType =
    | CreditCard
    | ViaCrd
    | MobilePay
    
